<?
//=>	정보 처리
function F_benefits($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									benefits 
									WHERE 
										benefits_no		=	'".$_L['benefits_no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);
	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO benefits(										
										benefits_no,
										d_check,
										d_scale,
										d_option,
										d_register_date,
										d_register_hour,
										d_register_minute,
										d_expire_date,
										d_expire_hour,
										d_expire_minute,
										d_day,
										d_object,
										d_out										
									)
							VALUES(									
										'".$_L['benefits_no']."',
										'".$_L['d_check']."',
										'".$_L['d_scale']."',
										'".$_L['d_option']."',
										'".$_L['d_register_date']."',
										'".$_L['d_register_hour']."',
										'".$_L['d_register_minute']."',
										'".$_L['d_expire_date']."',
										'".$_L['d_expire_hour']."',
										'".$_L['d_expire_minute']."',
										'".$_L['d_day']."',
										'".$_L['d_object']."',
										'".$_L['d_out']."'
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		$query		=	"UPDATE benefits SET
										".$add_query."										
										d_check			=	'".$_L['d_check']."',
										d_scale			=	'".$_L['d_scale']."',
										d_option		=	'".$_L['d_option']."',
										d_register_date	=	'".$_L['d_register_date']."',
										d_register_hour	=	'".$_L['d_register_hour']."',
										d_register_minute=	'".$_L['d_register_minute']."',
										d_expire_date	=	'".$_L['d_expire_date']."',
										d_expire_hour	=	'".$_L['d_expire_hour']."',
										d_expire_minute	=	'".$_L['d_expire_minute']."',
										d_day			=	'".$_L['d_day']."',
										d_object		=	'".$_L['d_object']."',
										d_out			=	'".$_L['d_out']."'
									WHERE
									benefits_no			=	'".$_L['benefits_no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM benefits
									WHERE
									benefits_no				=	'".$_L['benefits_no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_benefits_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY benefits_no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													benefits 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						benefits
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['benefits_no']);
	return $list;
}


?>
