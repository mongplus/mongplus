<?
//=>	정보 처리
function F_order_detail($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									order_detail 
									WHERE 
										detail_no		=	'".$_L['detail_no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);
	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO order_detail(										
										detail_no,
										order_no,
										or_name,
										or_tel,
										or_mobile,
										or_email,
										or_zipcode,
										or_addr1,
										or_addr2,
										re_name,
										re_tel,
										re_mobile,
										re_email,
										re_zipcode,
										re_addr1,
										re_addr2,
										order_memo										
									)
							VALUES(									
										'".$_L['detail_no']."',
										'".$_L['order_no']."',
										'".$_L['or_name']."',
										'".$_L['or_tel']."',
										'".$_L['or_mobile']."',
										'".$_L['or_email']."',
										'".$_L['or_zipcode']."',
										'".$_L['or_addr1']."',
										'".$_L['or_addr2']."',
										'".$_L['re_name']."',
										'".$_L['re_tel']."',
										'".$_L['re_mobile']."',
										'".$_L['re_email']."',
										'".$_L['re_zipcode']."',
										'".$_L['re_addr1']."',
										'".$_L['re_addr2']."',
										'".$_L['order_memo']."'
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		$query		=	"UPDATE order_detail SET
										".$add_query."										
										order_no		=	'".$_L['order_no']."',
										or_name			=	'".$_L['or_name']."',
										or_tel			=	'".$_L['or_tel']."',
										or_mobile		=	'".$_L['or_mobile']."',
										or_email		=	'".$_L['or_email']."',
										or_zipcode		=	'".$_L['or_zipcode']."',
										or_addr1		=	'".$_L['or_addr1']."',
										or_addr2		=	'".$_L['or_addr2']."',
										re_name			=	'".$_L['re_name']."',
										re_tel			=	'".$_L['re_tel']."',
										re_mobile		=	'".$_L['re_mobile']."',
										re_email		=	'".$_L['re_email']."',
										re_zipcode		=	'".$_L['re_zipcode']."',
										re_addr1		=	'".$_L['re_addr1']."',
										re_addr2		=	'".$_L['re_addr2']."',
										order_memo		=	'".$_L['order_memo']."'
									WHERE
									detail_no			=	'".$_L['detail_no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM order_detail
									WHERE
									detail_no				=	'".$_L['detail_no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_order_detail_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY detail_no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													order_detail 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						order_detail
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['detail_no']);
	return $list;
}


?>
