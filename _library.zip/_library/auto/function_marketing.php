<?
//=>	정보 처리
function F_marketing($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									marketing 
									WHERE 
										marketing_no		=	'".$_L['marketing_no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);
	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO marketing(										
										marketing_no,
										display,
										d_dateYN,
										r_date,
										e_date,
										gubun,
										d_category,
										d_page,
										link,
										a_link,
										m_position,
										file1,
										real_filename1,
										reg_date										
									)
							VALUES(									
										'".$_L['marketing_no']."',
										'".$_L['display']."',
										'".$_L['d_dateYN']."',
										'".$_L['r_date']."',
										'".$_L['e_date']."',
										'".$_L['gubun']."',
										'".$_L['d_category']."',
										'".$_L['d_page']."',
										'".$_L['link']."',
										'".$_L['a_link']."',
										'".$_L['m_position']."',
										'".$_L['file1']."',
										'".$_L['real_filename1']."',
										NOW()
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		$query		=	"UPDATE marketing SET
										".$add_query."										
										display			=	'".$_L['display']."',
										d_dateYN		=	'".$_L['d_dateYN']."',
										r_date			=	'".$_L['r_date']."',
										e_date			=	'".$_L['e_date']."',
										gubun			=	'".$_L['gubun']."',
										d_category		=	'".$_L['d_category']."',
										d_page			=	'".$_L['d_page']."',
										link			=	'".$_L['link']."',
										a_link			=	'".$_L['a_link']."',
										m_position		=	'".$_L['m_position']."',
										real_filename1	=	'".$_L['real_filename1']."'
									WHERE
									marketing_no			=	'".$_L['marketing_no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM marketing
									WHERE
									marketing_no				=	'".$_L['marketing_no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_marketing_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY marketing_no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													marketing 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						marketing
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['marketing_no']);
	return $list;
}


?>
