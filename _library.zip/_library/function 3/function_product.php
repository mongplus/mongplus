<?
//=>	정보 처리
function F_product($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									product 
									WHERE 
										product_no		=	'".$_L['product_no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);

	if($_L['mode'] == 'insert' || $_L['mode'] == 'update'){
		include_once $_SERVER['DOCUMENT_ROOT']."/_library/function_filter.php";

		$filt = $db->get_data("SELECT * FROM filter WHERE 1");
		$filts = array();
		if($filt['content'] != ''){
			if(strstr($filt['content'],",") != false){
				$filts = explode(",",$filt['content']);
			}else{
				$filts[] = $filt['content'];
			}
		}

		for($q=0;$q<count($filts);$q++){
			if(trim($filts[$q]) == ''){
				continue;
			}
			if(strstr($_L['product_name'],$filts[$q]) !== false){
				$_L['product_name'] = str_replace($filts[$q],"",$_L['product_name']);
			}

			if(strstr($_L['keyword'],$filts[$q]) !== false){
				$_L['keyword'] = str_replace($filts[$q],"",$_L['keyword']);
			}

			if(strstr($_L['detail'],$filts[$q]) !== false){
				$_L['detail'] = str_replace($filts[$q],"",$_L['detail']);
			}

			if(strstr($_L['p_name'],$filts[$q]) !== false){
				$_L['p_name'] = str_replace($filts[$q],"",$_L['p_name']);
			}

			if(strstr($_L['n_goods'],$filts[$q]) !== false){
				$_L['n_goods'] = str_replace($filts[$q],"",$_L['n_goods']);
			}

			if(strstr($_L['n_country'],$filts[$q]) !== false){
				$_L['n_country'] = str_replace($filts[$q],"",$_L['n_country']);
			}

			if(strstr($_L['n_income'],$filts[$q]) !== false){
				$_L['n_income'] = str_replace($filts[$q],"",$_L['n_income']);
			}

			if(strstr($_L['n_KC'],$filts[$q]) !== false){
				$_L['n_KC'] = str_replace($filts[$q],"",$_L['n_KC']);
			}

			if(strstr($_L['n_quality'],$filts[$q]) !== false){
				$_L['n_quality'] = str_replace($filts[$q],"",$_L['n_quality']);
			}

			if(strstr($_L['n_AS'],$filts[$q]) !== false){
				$_L['n_AS'] = str_replace($filts[$q],"",$_L['n_AS']);
			}

			if(strstr($_L['n_component'],$filts[$q]) !== false){
				$_L['n_component'] = str_replace($filts[$q],"",$_L['n_component']);
			}

			if(strstr($_L['n_color'],$filts[$q]) !== false){
				$_L['n_color'] = str_replace($filts[$q],"",$_L['n_color']);
			}

			if(strstr($_L['n_weight'],$filts[$q]) !== false){
				$_L['n_weight'] = str_replace($filts[$q],"",$_L['n_weight']);
			}

			if(strstr($_L['n_standard'],$filts[$q]) !== false){
				$_L['n_standard'] = str_replace($filts[$q],"",$_L['n_standard']);
			}
		}
	}

	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO product(										
										product_no,
										petYN,
										productYN,
										cate1_no,
										cate2_no,
										cate3_no,
										filterYN,
										f_no,
										showYN,
										product_name,
										product_code,
										auto_code,
										brand_no,
										status,
										keyword,
										file1,
										real_filename1,
										detail,
										price,
										s_price,
										d_YN,
										d_check,
										d_scale,
										d_option,
										d_register_date,
										d_register_hour,
										d_register_minute,
										d_expire_date,
										d_expire_hour,
										d_expire_minute,
										d_day,
										d_object,
										d_out,
										s_check,
										s_ratio,
										f_ratio,
										v_ratio,
										p_option,
										p_type,
										p_num,
										p_name,
										plus_p_type,
										sh_check,
										sh_info,
										sh_f_price,
										sh_st_price,
										sh_sh_price,
										iconYN,
										icon_r_date,
										icon_e_date,
										icon_type,
										noticeYN,
										n_goods,
										n_country,
										n_income,
										n_KC,
										n_quality,
										n_AS,
										n_component,
										n_color,
										n_weight,
										n_standard,
										hit,
										recommend,
										write_id,
										reg_date										
									)
							VALUES(									
										'".$_L['product_no']."',
										'".$_L['petYN']."',
										'".$_L['productYN']."',
										'".$_L['cate1_no']."',
										'".$_L['cate2_no']."',
										'".$_L['cate3_no']."',
										'".$_L['filterYN']."',
										'".$_L['f_no']."',
										'".$_L['showYN']."',
										'".$_L['product_name']."',
										'".$_L['product_code']."',
										'".$_L['auto_code']."',
										'".$_L['brand_no']."',
										'".$_L['status']."',
										'".$_L['keyword']."',
										'".$_L['file1']."',
										'".$_L['real_filename1']."',
										'".$_L['detail']."',
										'".$_L['price']."',
										'".$_L['s_price']."',
										'".$_L['d_YN']."',
										'".$_L['d_check']."',
										'".$_L['d_scale']."',
										'".$_L['d_option']."',
										'".$_L['d_register_date']."',
										'".$_L['d_register_hour']."',
										'".$_L['d_register_minute']."',
										'".$_L['d_expire_date']."',
										'".$_L['d_expire_hour']."',
										'".$_L['d_expire_minute']."',
										'".$_L['d_day']."',
										'".$_L['d_object']."',
										'".$_L['d_out']."',
										'".$_L['s_check']."',
										'".$_L['s_ratio']."',
										'".$_L['f_ratio']."',
										'".$_L['v_ratio']."',
										'".$_L['p_option']."',
										'".$_L['p_type']."',
										'".$_L['p_num']."',
										'".$_L['p_name']."',
										'".$_L['plus_p_type']."',
										'".$_L['sh_check']."',
										'".$_L['sh_info']."',
										'".$_L['sh_f_price']."',
										'".$_L['sh_st_price']."',
										'".$_L['sh_sh_price']."',
										'".$_L['iconYN']."',
										'".$_L['icon_r_date']."',
										'".$_L['icon_e_date']."',
										'".$_L['icon_type']."',
										'".$_L['noticeYN']."',
										'".$_L['n_goods']."',
										'".$_L['n_country']."',
										'".$_L['n_income']."',
										'".$_L['n_KC']."',
										'".$_L['n_quality']."',
										'".$_L['n_AS']."',
										'".$_L['n_component']."',
										'".$_L['n_color']."',
										'".$_L['n_weight']."',
										'".$_L['n_standard']."',
										'".$_L['hit']."',
										'".$_L['recommend']."',
										'".$_L['write_id']."',
										NOW()
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		$query		=	"UPDATE product SET
										".$add_query."										
										petYN			=	'".$_L['petYN']."',
										productYN		=	'".$_L['productYN']."',
										cate1_no		=	'".$_L['cate1_no']."',
										cate2_no		=	'".$_L['cate2_no']."',
										cate3_no		=	'".$_L['cate3_no']."',
										filterYN		=	'".$_L['filterYN']."',
										f_no			=	'".$_L['f_no']."',
										showYN			=	'".$_L['showYN']."',
										product_name	=	'".$_L['product_name']."',
										product_code	=	'".$_L['product_code']."',
										auto_code		=	'".$_L['auto_code']."',
										brand_no		=	'".$_L['brand_no']."',
										status			=	'".$_L['status']."',
										keyword			=	'".$_L['keyword']."',
										real_filename1	=	'".$_L['real_filename1']."',
										detail			=	'".$_L['detail']."',
										price			=	'".$_L['price']."',
										s_price			=	'".$_L['s_price']."',
										d_YN			=	'".$_L['d_YN']."',
										d_check			=	'".$_L['d_check']."',
										d_scale			=	'".$_L['d_scale']."',
										d_option		=	'".$_L['d_option']."',
										d_register_date	=	'".$_L['d_register_date']."',
										d_register_hour	=	'".$_L['d_register_hour']."',
										d_register_minute=	'".$_L['d_register_minute']."',
										d_expire_date	=	'".$_L['d_expire_date']."',
										d_expire_hour	=	'".$_L['d_expire_hour']."',
										d_expire_minute	=	'".$_L['d_expire_minute']."',
										d_day			=	'".$_L['d_day']."',
										d_object		=	'".$_L['d_object']."',
										d_out			=	'".$_L['d_out']."',
										s_check			=	'".$_L['s_check']."',
										s_ratio			=	'".$_L['s_ratio']."',
										f_ratio			=	'".$_L['f_ratio']."',
										v_ratio			=	'".$_L['v_ratio']."',
										p_option		=	'".$_L['p_option']."',
										p_type			=	'".$_L['p_type']."',
										p_num			=	'".$_L['p_num']."',
										p_name			=	'".$_L['p_name']."',
										plus_p_type		=	'".$_L['plus_p_type']."',
										sh_check		=	'".$_L['sh_check']."',
										sh_info			=	'".$_L['sh_info']."',
										sh_f_price		=	'".$_L['sh_f_price']."',
										sh_st_price		=	'".$_L['sh_st_price']."',
										sh_sh_price		=	'".$_L['sh_sh_price']."',
										iconYN			=	'".$_L['iconYN']."',
										icon_r_date		=	'".$_L['icon_r_date']."',
										icon_e_date		=	'".$_L['icon_e_date']."',
										icon_type		=	'".$_L['icon_type']."',
										noticeYN		=	'".$_L['noticeYN']."',
										n_goods			=	'".$_L['n_goods']."',
										n_country		=	'".$_L['n_country']."',
										n_income		=	'".$_L['n_income']."',
										n_KC			=	'".$_L['n_KC']."',
										n_quality		=	'".$_L['n_quality']."',
										n_AS			=	'".$_L['n_AS']."',
										n_component		=	'".$_L['n_component']."',
										n_color			=	'".$_L['n_color']."',
										n_weight		=	'".$_L['n_weight']."',
										n_standard		=	'".$_L['n_standard']."',
										write_id		=	'".$_L['write_id']."'
									WHERE
									product_no			=	'".$_L['product_no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM product
									WHERE
									product_no				=	'".$_L['product_no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_product_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY product_no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													product 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						product
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['product_no']);
	return $list;
}


?>
