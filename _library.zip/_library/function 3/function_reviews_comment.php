<?
//=>	정보 처리
function F_reviews_comment($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									reviews_comment 
									WHERE 
										comment_no		=	'".$_L['comment_no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);

	if($_L['mode'] == 'insert' || $_L['mode'] == 'update'){
		include_once $_SERVER['DOCUMENT_ROOT']."/_library/function_filter.php";

		$filt = $db->get_data("SELECT * FROM filter WHERE 1");
		$filts = array();
		if($filt['content'] != ''){
			if(strstr($filt['content'],",") != false){
				$filts = explode(",",$filt['content']);
			}else{
				$filts[] = $filt['content'];
			}
		}

		for($q=0;$q<count($filts);$q++){
			if(trim($filts[$q]) == ''){
				continue;
			}
			if(strstr($_L['content'],$filts[$q]) !== false){
				$_L['content'] = str_replace($filts[$q],"",$_L['content']);
			}
		}
	}

	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO reviews_comment(										
										comment_no,
										reviews_no,
										member_no,
										up_num,
										down_num,
										content,
										reg_date										
									)
							VALUES(									
										'".$_L['comment_no']."',
										'".$_L['reviews_no']."',
										'".$_L['member_no']."',
										'".$_L['up_num']."',
										'".$_L['down_num']."',
										'".$_L['content']."',
										NOW()
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		$query		=	"UPDATE reviews_comment SET
										".$add_query."										
										reviews_no		=	'".$_L['reviews_no']."',
										member_no		=	'".$_L['member_no']."',
										up_num			=	'".$_L['up_num']."',
										down_num		=	'".$_L['down_num']."',
										content			=	'".$_L['content']."'
									WHERE
									comment_no			=	'".$_L['comment_no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM reviews_comment
									WHERE
									comment_no				=	'".$_L['comment_no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_reviews_comment_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY comment_no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													reviews_comment 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						reviews_comment
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['comment_no']);
	return $list;
}


?>
