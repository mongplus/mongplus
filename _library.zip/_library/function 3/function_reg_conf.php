<?
//=>	정보 처리
function F_reg_conf($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									reg_conf 
									WHERE 
										no		=	'".$_L['no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);

	if($_L['mode'] == 'insert' || $_L['mode'] == 'update'){
		include_once $_SERVER['DOCUMENT_ROOT']."/_library/function_filter.php";

		$filt = $db->get_data("SELECT * FROM filter WHERE 1");
		$filts = array();
		if($filt['content'] != ''){
			if(strstr($filt['content'],",") != false){
				$filts = explode(",",$filt['content']);
			}else{
				$filts[] = $filt['content'];
			}
		}

		for($q=0;$q<count($filts);$q++){
			if(trim($filts[$q]) == ''){
				continue;
			}
			if(strstr($_L['company'],$filts[$q]) !== false){
				$_L['company'] = str_replace($filts[$q],"",$_L['company']);
			}

			if(strstr($_L['represent'],$filts[$q]) !== false){
				$_L['represent'] = str_replace($filts[$q],"",$_L['represent']);
			}

			if(strstr($_L['addr1'],$filts[$q]) !== false){
				$_L['addr1'] = str_replace($filts[$q],"",$_L['addr1']);
			}

			if(strstr($_L['addr2'],$filts[$q]) !== false){
				$_L['addr2'] = str_replace($filts[$q],"",$_L['addr2']);
			}

			if(strstr($_L['registration'],$filts[$q]) !== false){
				$_L['registration'] = str_replace($filts[$q],"",$_L['registration']);
			}

			if(strstr($_L['n_report'],$filts[$q]) !== false){
				$_L['n_report'] = str_replace($filts[$q],"",$_L['n_report']);
			}

			if(strstr($_L['d_person'],$filts[$q]) !== false){
				$_L['d_person'] = str_replace($filts[$q],"",$_L['d_person']);
			}
		}
	}

	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO reg_conf(										
										no,
										company,
										tel,
										cs_no,
										date,
										fax,
										represent,
										zipcode,
										addr1,
										addr2,
										email,
										registration,
										n_report,
										d_person,
										d_email,
										reg_date										
									)
							VALUES(									
										'".$_L['no']."',
										'".$_L['company']."',
										'".$_L['tel']."',
										'".$_L['cs_no']."',
										'".$_L['date']."',
										'".$_L['fax']."',
										'".$_L['represent']."',
										'".$_L['zipcode']."',
										'".$_L['addr1']."',
										'".$_L['addr2']."',
										'".$_L['email']."',
										'".$_L['registration']."',
										'".$_L['n_report']."',
										'".$_L['d_person']."',
										'".$_L['d_email']."',
										NOW()
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		$query		=	"UPDATE reg_conf SET
										".$add_query."										
										company			=	'".$_L['company']."',
										tel				=	'".$_L['tel']."',
										cs_no			=	'".$_L['cs_no']."',
										date			=	'".$_L['date']."',
										fax				=	'".$_L['fax']."',
										represent		=	'".$_L['represent']."',
										zipcode			=	'".$_L['zipcode']."',
										addr1			=	'".$_L['addr1']."',
										addr2			=	'".$_L['addr2']."',
										email			=	'".$_L['email']."',
										registration	=	'".$_L['registration']."',
										n_report		=	'".$_L['n_report']."',
										d_person		=	'".$_L['d_person']."',
										d_email			=	'".$_L['d_email']."'
									WHERE
									no			=	'".$_L['no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM reg_conf
									WHERE
									no				=	'".$_L['no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_reg_conf_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													reg_conf 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						reg_conf
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['no']);
	return $list;
}


?>
