<?
//=>	정보 처리
function F_product_plus($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									product_plus 
									WHERE 
										detail_no		=	'".$_L['detail_no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);
	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO product_plus(										
										detail_no,
										product_no,
										plus_product_no,
										price,
										display,
										stockYN										
									)
							VALUES(									
										'".$_L['detail_no']."',
										'".$_L['product_no']."',
										'".$_L['plus_product_no']."',
										'".$_L['price']."',
										'".$_L['display']."',
										'".$_L['stockYN']."'
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		$query		=	"UPDATE product_plus SET
										".$add_query."										
										product_no		=	'".$_L['product_no']."',
										plus_product_no	=	'".$_L['plus_product_no']."',
										price			=	'".$_L['price']."',
										display			=	'".$_L['display']."',
										stockYN			=	'".$_L['stockYN']."'
									WHERE
									detail_no			=	'".$_L['detail_no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM product_plus
									WHERE
									detail_no				=	'".$_L['detail_no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_product_plus_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY detail_no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													product_plus 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						product_plus
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['detail_no']);
	return $list;
}


?>
