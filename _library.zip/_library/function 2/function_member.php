<?
//=>	정보 처리
function F_member($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									member 
									WHERE 
										member_no		=	'".$_L['member_no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);

	if($_L['mode'] == 'insert' || $_L['mode'] == 'update'){
		include_once $_SERVER['DOCUMENT_ROOT']."/_library/function_filter.php";

		$filt = $db->get_data("SELECT * FROM filter WHERE 1");
		$filts = array();
		if($filt['content'] != ''){
			if(strstr($filt['content'],",") != false){
				$filts = explode(",",$filt['content']);
			}else{
				$filts[] = $filt['content'];
			}
		}

		for($q=0;$q<count($filts);$q++){
			if(trim($filts[$q]) == ''){
				continue;
			}

			if(strstr($_L['name'],$filts[$q]) !== false){
				$_L['name'] = str_replace($filts[$q],"",$_L['name']);
			}

			if(strstr($_L['nickname'],$filts[$q]) !== false){
				$_L['nickname'] = str_replace($filts[$q],"",$_L['nickname']);
			}

			if(strstr($_L['address1'],$filts[$q]) !== false){
				$_L['address1'] = str_replace($filts[$q],"",$_L['address1']);
			}

			if(strstr($_L['address2'],$filts[$q]) !== false){
				$_L['address2'] = str_replace($filts[$q],"",$_L['address2']);
			}

			if(strstr($_L['option_data'],$filts[$q]) !== false){
				$_L['option_data'] = str_replace($filts[$q],"",$_L['option_data']);
			}

			if(strstr($_L['license_name'],$filts[$q]) !== false){
				$_L['license_name'] = str_replace($filts[$q],"",$_L['license_name']);
			}

			if(strstr($_L['one_text'],$filts[$q]) !== false){
				$_L['one_text'] = str_replace($filts[$q],"",$_L['one_text']);
			}
		}
	}

	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO member(										
										member_no,
										user_id,
										passwd,
										name,
										nickname,
										sex,
										level,
										tel,
										email,
										address1,
										address2,
										zipcode,
										option_no,
										option_data,
										licenseYN,
										license_name,
										file1,
										real_filename1,
										file2,
										real_filename2,
										city_no,
										area_no,
										dong_no,
										is_use,
										is_mail,
										is_sms,
										is_push,
										is_main,
										is_main_order,
										license_type,
										navi_no,
										auth_code,
										memo,
										content,
										last_date,
										keyword,
										reg_date										
									)
							VALUES(									
										'".$_L['member_no']."',
										'".trim($_L['user_id'])."',
										'".$_L['passwd']."',
										'".$_L['name']."',
										'".$_L['nickname']."',
										'".$_L['sex']."',
										'".$_L['level']."',
										'".$_L['tel']."',
										'".$_L['email']."',
										'".$_L['address1']."',
										'".$_L['address2']."',
										'".$_L['zipcode']."',
										'".$_L['option_no']."',
										'".$_L['option_data']."',
										'".$_L['licenseYN']."',
										'".$_L['license_name']."',
										'".$_L['file1']."',
										'".$_L['real_filename1']."',
										'".$_L['file2']."',
										'".$_L['real_filename2']."',
										'".$_L['city_no']."',
										'".$_L['area_no']."',
										'".$_L['dong_no']."',
										'".$_L['is_use']."',
										'".$_L['is_mail']."',
										'".$_L['is_sms']."',
										'".$_L['is_push']."',
										'".$_L['is_main']."',
										'".$_L['is_main_order']."',
										'".$_L['license_type']."',
										'".$_L['navi_no']."',
										'".$_L['auth_code']."',
										'".$_L['memo']."',
										'".$_L['content']."',
										'".$_L['last_date']."',
										'".$_L['keyword']."',
										NOW()
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		if ($_L['file2'])	$add_query			.=	"file2		=	'".$_L['file2']."',";
		$query		=	"UPDATE member SET
										".$add_query."										
										user_id			=	'".trim($_L['user_id'])."',
										passwd			=	'".$_L['passwd']."',
										name			=	'".$_L['name']."',
										nickname		=	'".$_L['nickname']."',
										sex				=	'".$_L['sex']."',
										level			=	'".$_L['level']."',
										tel				=	'".$_L['tel']."',
										email			=	'".$_L['email']."',
										address1		=	'".$_L['address1']."',
										address2		=	'".$_L['address2']."',
										zipcode			=	'".$_L['zipcode']."',
										option_no		=	'".$_L['option_no']."',
										option_data		=	'".$_L['option_data']."',
										licenseYN		=	'".$_L['licenseYN']."',
										license_name	=	'".$_L['license_name']."',
										real_filename1	=	'".$_L['real_filename1']."',
										real_filename2	=	'".$_L['real_filename2']."',
										city_no			=	'".$_L['city_no']."',
										area_no			=	'".$_L['area_no']."',
										dong_no			=	'".$_L['dong_no']."',
										is_use			=	'".$_L['is_use']."',
										is_mail			=	'".$_L['is_mail']."',
										is_sms			=	'".$_L['is_sms']."',
										is_push			=	'".$_L['is_push']."',
										is_main			=	'".$_L['is_main']."',
										is_main_order	=	'".$_L['is_main_order']."',
										license_type	=	'".$_L['license_type']."',
										navi_no			=	'".$_L['navi_no']."',
										auth_code		=	'".$_L['auth_code']."',
										memo			=	'".$_L['memo']."',
										content			=	'".$_L['content']."',
										one_text		=	'".$_L['one_text']."',
										F_link			=	'".$_L['F_link']."',
										I_link			=	'".$_L['I_link']."',
										N_link			=	'".$_L['N_link']."',
										Y_link			=	'".$_L['Y_link']."',
										K_link			=	'".$_L['K_link']."',
										T_link			=	'".$_L['T_link']."',
										last_date		=	'".$_L['last_date']."',
										keyword			=	'".$_L['keyword']."'
									WHERE
									member_no			=	'".$_L['member_no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM member
									WHERE
									member_no				=	'".$_L['member_no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_member_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY member_no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													member 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						member
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['member_no']);
	return $list;
}


?>
