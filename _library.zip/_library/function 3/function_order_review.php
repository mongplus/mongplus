<?
//=>	정보 처리
function F_order_review($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									order_review 
									WHERE 
										review_no		=	'".$_L['review_no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);

	if($_L['mode'] == 'insert' || $_L['mode'] == 'update'){
		include_once $_SERVER['DOCUMENT_ROOT']."/_library/function_filter.php";

		$filt = $db->get_data("SELECT * FROM filter WHERE 1");
		$filts = array();
		if($filt['content'] != ''){
			if(strstr($filt['content'],",") != false){
				$filts = explode(",",$filt['content']);
			}else{
				$filts[] = $filt['content'];
			}
		}

		for($q=0;$q<count($filts);$q++){
			if(trim($filts[$q]) == ''){
				continue;
			}
			if(strstr($_L['content'],$filts[$q]) !== false){
				$_L['content'] = str_replace($filts[$q],"",$_L['content']);
			}
		}
	}

	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO order_review(										
										review_no,
										product_no,
										order_no,
										oitem_no,
										member_no,
										grade,
										content,
										file1,
										real_filename1,
										file2,
										real_filename2,
										file3,
										real_filename3,
										file4,
										real_filename4,
										file5,
										real_filename5,
										file6,
										real_filename6,
										file7,
										real_filename7,
										file8,
										real_filename8,
										file9,
										real_filename9,
										file10,
										real_filename10,
										reg_date										
									)
							VALUES(									
										'".$_L['review_no']."',
										'".$_L['product_no']."',
										'".$_L['order_no']."',
										'".$_L['oitem_no']."',
										'".$_L['member_no']."',
										'".$_L['grade']."',
										'".$_L['content']."',
										'".$_L['file1']."',
										'".$_L['real_filename1']."',
										'".$_L['file2']."',
										'".$_L['real_filename2']."',
										'".$_L['file3']."',
										'".$_L['real_filename3']."',
										'".$_L['file4']."',
										'".$_L['real_filename4']."',
										'".$_L['file5']."',
										'".$_L['real_filename5']."',
										'".$_L['file6']."',
										'".$_L['real_filename6']."',
										'".$_L['file7']."',
										'".$_L['real_filename7']."',
										'".$_L['file8']."',
										'".$_L['real_filename8']."',
										'".$_L['file9']."',
										'".$_L['real_filename9']."',
										'".$_L['file10']."',
										'".$_L['real_filename10']."',
										NOW()
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		if ($_L['file2'])	$add_query			.=	"file2		=	'".$_L['file2']."',";
		if ($_L['file3'])	$add_query			.=	"file3		=	'".$_L['file3']."',";
		if ($_L['file4'])	$add_query			.=	"file4		=	'".$_L['file4']."',";
		if ($_L['file5'])	$add_query			.=	"file5		=	'".$_L['file5']."',";
		if ($_L['file6'])	$add_query			.=	"file6		=	'".$_L['file6']."',";
		if ($_L['file7'])	$add_query			.=	"file7		=	'".$_L['file7']."',";
		if ($_L['file8'])	$add_query			.=	"file8		=	'".$_L['file8']."',";
		if ($_L['file9'])	$add_query			.=	"file9		=	'".$_L['file9']."',";
		if ($_L['file10'])	$add_query			.=	"file10		=	'".$_L['file10']."',";
		$query		=	"UPDATE order_review SET
										".$add_query."										
										product_no		=	'".$_L['product_no']."',
										order_no		=	'".$_L['order_no']."',
										oitem_no		=	'".$_L['oitem_no']."',
										member_no		=	'".$_L['member_no']."',
										grade			=	'".$_L['grade']."',
										content			=	'".$_L['content']."',
										real_filename1	=	'".$_L['real_filename1']."',
										real_filename2	=	'".$_L['real_filename2']."',
										real_filename3	=	'".$_L['real_filename3']."',
										real_filename4	=	'".$_L['real_filename4']."',
										real_filename5	=	'".$_L['real_filename5']."',
										file6			=	'".$_L['file6']."',
										real_filename6	=	'".$_L['real_filename6']."',
										file7			=	'".$_L['file7']."',
										real_filename7	=	'".$_L['real_filename7']."',
										file8			=	'".$_L['file8']."',
										real_filename8	=	'".$_L['real_filename8']."',
										file9			=	'".$_L['file9']."',
										real_filename9	=	'".$_L['real_filename9']."',
										file10			=	'".$_L['file10']."',
										real_filename10	=	'".$_L['real_filename10']."'
									WHERE
									review_no			=	'".$_L['review_no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM order_review
									WHERE
									review_no				=	'".$_L['review_no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_order_review_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY review_no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													order_review 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						order_review
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['review_no']);
	return $list;
}

//=>	 목록 불러오기
function F_order_review_list2($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY r.review_no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
														count(*)
													FROM
														order_review AS r 
													LEFT JOIN 
														`order` AS o ON (r.order_no=o.order_no)
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						order_review AS r 
					LEFT JOIN 
						`order` AS o ON (r.order_no=o.order_no)
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['review_no']);
	return $list;
}


?>
