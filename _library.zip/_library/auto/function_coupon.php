<?
//=>	정보 처리
function F_coupon($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									coupon 
									WHERE 
										coupon_no		=	'".$_L['coupon_no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);

	if($_L['mode'] == 'insert' || $_L['mode'] == 'update'){
		include_once $_SERVER['DOCUMENT_ROOT']."/_library/function_filter.php";

		$filt = $db->get_data("SELECT * FROM filter WHERE 1");
		$filts = array();
		if($filt['content'] != ''){
			if(strstr($filt['content'],",") != false){
				$filts = explode(",",$filt['content']);
			}else{
				$filts[] = $filt['content'];
			}
		}

		for($q=0;$q<count($filts);$q++){
			if(trim($filts[$q]) == ''){
				continue;
			}

			if(strstr($_L['coupon_name'],$filts[$q]) !== false){
				$_L['coupon_name'] = str_replace($filts[$q],"",$_L['coupon_name']);
			}

			if(strstr($_L['content'],$filts[$q]) !== false){
				$_L['content'] = str_replace($filts[$q],"",$_L['content']);
			}
		}
	}

	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO coupon(										
										coupon_no,
										coupon_name,
										content,
										code,
										gubun,
										savingsYN,
										m_levelYN,
										num,
										restore,
										benefitYN,
										ben_price,
										ben_persent,
										issue,
										issue_detail1,
										issue_detail2,
										issue_time,
										issue_date,
										issue_hour,
										issue_minute,
										isset_datetime,
										r_date,
										r_hour,
										r_minute,
										r_datetime,
										e_date,
										e_hour,
										e_minute,
										e_datetime,
										scope,
										applyTp,
										apply_cate,
										apply_brand,
										apply_product,
										price,
										status,
										reg_date										
									)
							VALUES(									
										'".$_L['coupon_no']."',
										'".$_L['coupon_name']."',
										'".$_L['content']."',
										'".$_L['code']."',
										'".$_L['gubun']."',
										'".$_L['savingsYN']."',
										'".$_L['m_levelYN']."',
										'".$_L['num']."',
										'".$_L['restore']."',
										'".$_L['benefitYN']."',
										'".$_L['ben_price']."',
										'".$_L['ben_persent']."',
										'".$_L['issue']."',
										'".$_L['issue_detail1']."',
										'".$_L['issue_detail2']."',
										'".$_L['issue_time']."',
										'".$_L['issue_date']."',
										'".$_L['issue_hour']."',
										'".$_L['issue_minute']."',
										'".$_L['isset_datetime']."',
										'".$_L['r_date']."',
										'".$_L['r_hour']."',
										'".$_L['r_minute']."',
										'".$_L['r_datetime']."',
										'".$_L['e_date']."',
										'".$_L['e_hour']."',
										'".$_L['e_minute']."',
										'".$_L['e_datetime']."',
										'".$_L['scope']."',
										'".$_L['applyTp']."',
										'".$_L['apply_cate']."',
										'".$_L['apply_brand']."',
										'".$_L['apply_product']."',
										'".$_L['price']."',
										'".$_L['status']."',
										NOW()
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		$query		=	"UPDATE coupon SET
										".$add_query."										
										coupon_name		=	'".$_L['coupon_name']."',
										content			=	'".$_L['content']."',
										gubun			=	'".$_L['gubun']."',
										savingsYN		=	'".$_L['savingsYN']."',
										m_levelYN		=	'".$_L['m_levelYN']."',
										num				=	'".$_L['num']."',
										restore			=	'".$_L['restore']."',
										benefitYN		=	'".$_L['benefitYN']."',
										ben_price		=	'".$_L['ben_price']."',
										ben_persent		=	'".$_L['ben_persent']."',
										issue			=	'".$_L['issue']."',
										issue_detail1	=	'".$_L['issue_detail1']."',
										issue_detail2	=	'".$_L['issue_detail2']."',
										issue_time		=	'".$_L['issue_time']."',
										issue_date		=	'".$_L['issue_date']."',
										issue_hour		=	'".$_L['issue_hour']."',
										issue_minute	=	'".$_L['issue_minute']."',
										isset_datetime	=	'".$_L['isset_datetime']."',
										r_date			=	'".$_L['r_date']."',
										r_hour			=	'".$_L['r_hour']."',
										r_minute		=	'".$_L['r_minute']."',
										r_datetime		=	'".$_L['r_datetime']."',
										e_date			=	'".$_L['e_date']."',
										e_hour			=	'".$_L['e_hour']."',
										e_minute		=	'".$_L['e_minute']."',
										e_datetime		=	'".$_L['e_datetime']."',
										scope			=	'".$_L['scope']."',
										applyTp			=	'".$_L['applyTp']."',
										apply_cate		=	'".$_L['apply_cate']."',
										apply_brand		=	'".$_L['apply_brand']."',
										apply_product	=	'".$_L['apply_product']."',
										price			=	'".$_L['price']."'
									WHERE
									coupon_no			=	'".$_L['coupon_no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM coupon
									WHERE
									coupon_no				=	'".$_L['coupon_no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_coupon_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY coupon_no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													coupon 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						coupon
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['coupon_no']);
	return $list;
}


?>
