<?
//=>	정보 처리
function F_staff($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									staff 
									WHERE 
										no		=	'".$_L['no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);

	if($_L['mode'] == 'insert' || $_L['mode'] == 'update'){
		include_once $_SERVER['DOCUMENT_ROOT']."/_library/function_filter.php";

		$filt = $db->get_data("SELECT * FROM filter WHERE 1");
		$filts = array();
		if($filt['content'] != ''){
			if(strstr($filt['content'],",") != false){
				$filts = explode(",",$filt['content']);
			}else{
				$filts[] = $filt['content'];
			}
		}

		for($q=0;$q<count($filts);$q++){
			if(trim($filts[$q]) == ''){
				continue;
			}
			if(strstr($_L['name'],$filts[$q]) !== false){
				$_L['name'] = str_replace($filts[$q],"",$_L['name']);
			}

			if(strstr($_L['nickname'],$filts[$q]) !== false){
				$_L['nickname'] = str_replace($filts[$q],"",$_L['nickname']);
			}

			if(strstr($_L['address1'],$filts[$q]) !== false){
				$_L['address1'] = str_replace($filts[$q],"",$_L['address1']);
			}

			if(strstr($_L['address2'],$filts[$q]) !== false){
				$_L['address2'] = str_replace($filts[$q],"",$_L['address2']);
			}

			if(strstr($_L['memo'],$filts[$q]) !== false){
				$_L['memo'] = str_replace($filts[$q],"",$_L['memo']);
			}
		}
	}

	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO staff(										
										no,
										user_id,
										passwd,
										name,
										nickname,
										level,
										position,
										tel,
										email,
										address1,
										address2,
										zipcode,
										is_use,
										memo,
										reg_date										
									)
							VALUES(									
										'".$_L['no']."',
										'".$_L['user_id']."',
										'".$_L['passwd']."',
										'".$_L['name']."',
										'".$_L['nickname']."',
										'".$_L['level']."',
										'".$_L['position']."',
										'".$_L['tel']."',
										'".$_L['email']."',
										'".$_L['address1']."',
										'".$_L['address2']."',
										'".$_L['zipcode']."',
										'".$_L['is_use']."',
										'".$_L['memo']."',
										NOW()
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		$query		=	"UPDATE staff SET
										".$add_query."										
										user_id			=	'".$_L['user_id']."',
										passwd			=	'".$_L['passwd']."',
										name			=	'".$_L['name']."',
										nickname		=	'".$_L['nickname']."',
										level			=	'".$_L['level']."',
										position		=	'".$_L['position']."',
										tel				=	'".$_L['tel']."',
										email			=	'".$_L['email']."',
										address1		=	'".$_L['address1']."',
										address2		=	'".$_L['address2']."',
										zipcode			=	'".$_L['zipcode']."',
										is_use			=	'".$_L['is_use']."',
										memo			=	'".$_L['memo']."'
									WHERE
									no			=	'".$_L['no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM staff
									WHERE
									no				=	'".$_L['no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_staff_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													staff 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						staff
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['no']);
	return $list;
}


?>
