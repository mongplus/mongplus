<?
//=>	정보 처리
function F_notice($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									notice 
									WHERE 
										notice_no		=	'".$_L['notice_no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);

	if($_L['mode'] == 'insert' || $_L['mode'] == 'update'){
		include_once $_SERVER['DOCUMENT_ROOT']."/_library/function_filter.php";

		$filt = $db->get_data("SELECT * FROM filter WHERE 1");
		$filts = array();
		if($filt['content'] != ''){
			if(strstr($filt['content'],",") != false){
				$filts = explode(",",$filt['content']);
			}else{
				$filts[] = $filt['content'];
			}
		}

		for($q=0;$q<count($filts);$q++){
			if(trim($filts[$q]) == ''){
				continue;
			}

			if(strstr($_L['title'],$filts[$q]) !== false){
				$_L['title'] = str_replace($filts[$q],"",$_L['title']);
			}

			if(strstr($_L['content'],$filts[$q]) !== false){
				$_L['content'] = str_replace($filts[$q],"",$_L['content']);
			}

		}
	}


	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO notice(										
										notice_no,
										gubun,
										title,
										content,
										file1,
										real_filename1,
										file2,
										real_filename2,
										file3,
										real_filename3,
										hit,
										name,
										write_id,
										reg_date										
									)
							VALUES(									
										'".$_L['notice_no']."',
										'".$_L['gubun']."',
										'".$_L['title']."',
										'".$_L['content']."',
										'".$_L['file1']."',
										'".$_L['real_filename1']."',
										'".$_L['file2']."',
										'".$_L['real_filename2']."',
										'".$_L['file3']."',
										'".$_L['real_filename3']."',
										'".$_L['hit']."',
										'".$_L['name']."',
										'".$_L['write_id']."',
										NOW()
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		if ($_L['file2'])	$add_query			.=	"file2		=	'".$_L['file2']."',";
		if ($_L['file3'])	$add_query			.=	"file3		=	'".$_L['file3']."',";
		$query		=	"UPDATE notice SET
										".$add_query."										
										gubun			=	'".$_L['gubun']."',
										title			=	'".$_L['title']."',
										content			=	'".$_L['content']."',
										real_filename1	=	'".$_L['real_filename1']."',
										real_filename2	=	'".$_L['real_filename2']."',
										real_filename3	=	'".$_L['real_filename3']."',
										hit				=	'".$_L['hit']."',
										name			=	'".$_L['name']."',
										write_id		=	'".$_L['write_id']."'
									WHERE
									notice_no			=	'".$_L['notice_no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM notice
									WHERE
									notice_no				=	'".$_L['notice_no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_notice_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY notice_no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													notice 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						notice
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['notice_no']);
	return $list;
}


?>
