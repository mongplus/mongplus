<?
if (!$F_code){
//=>	카테고리정보 처리
function F_code($_L){
	global $db;
	if ($_L['mode'] == 'read'){
		if ($_L['no']){
			$add_query			=	"  no			=	'".$_L['no']."' ";
		}

		if ($_L['c_code']){
			$add_query			=	"  c_code		=	'".$_L['c_code']."' ";
		}

		if ($add_query == null){
			alert_print("해당 코드가 존재하지 않습니다.");
			history_go();
			exit;
		}

		$cat_info		=	$db->get_data("
									SELECT 
										*
									FROM 
									code 
									WHERE 
									$add_query
									");
	return	$cat_info;
	}

	if ($_L['mode'] == 'read_code'){
		if ($_L['no']){
			$add_query			=	"  no			=	'".$_L['no']."' ";
		}

		if ($_L['c_code']){
			$add_query			=	"  c_code		=	'".$_L['c_code']."' ";
		}

		if ($add_query == null){
			alert_print("해당 코드가 존재하지 않습니다.");
			history_go();
			exit;
		}
		$cat_info		=	$db->get_data("
									SELECT 
										c_name
									FROM 
									code 
									WHERE 
									$add_query
									");
	return	$cat_info['c_name'];
	}

	//=>	마지막 코드 가져오기
	if ($_L['mode'] == 'last_code' ){
		$R['c_parent']		=	$_L['c_code'];
		$last_code			=	$db->get_data_one("
									SELECT 
										c_code, length(c_code)
									FROM 
									code 
									WHERE 
									c_parent		=	'".$R['c_parent']."' 
									AND length(c_code) = (SELECT MAX(length(c_code)) FROM code WHERE c_parent		=	'".$R['c_parent']."') ORDER BY c_code DESC
						");

		//=>	새로운 코드
		if($_L['depth'] == 'top'){
			if ($last_code == null){
				$R['c_code']			=	'100';
			}
			else{
				$R['c_code']			=	$last_code + 100;
				if (strlen($R['c_code'])%3 != 0){
					$R['c_code']			=	'0'.$R['c_code'];
				}
			}
		}else{		//	cat2.html 인 경우
			if ($last_code == null){
				$R['c_code']			=	$R['c_parent'].'010';
			}
			else{
				$R['c_code']			=	$last_code + 10;
				if (strlen($R['c_code'])%3 != 0){
					$R['c_code']			=	'0'.$R['c_code'];
				}
			}
		}

	return $R;
		 
	}

	if($_L['mode'] == 'insert' || $_L['mode'] == 'update'){
		include_once $_SERVER['DOCUMENT_ROOT']."/_library/function_filter.php";

		$filt = $db->get_data("SELECT * FROM filter WHERE 1");
		$filts = array();
		if($filt['content'] != ''){
			if(strstr($filt['content'],",") != false){
				$filts = explode(",",$filt['content']);
			}else{
				$filts[] = $filt['content'];
			}
		}

		for($q=0;$q<count($filts);$q++){
			if(strstr($_L['c_name'],$filts[$q]) !== false){
				$_L['c_name'] = str_replace($filts[$q],"",$_L['c_name']);
			}

			if(strstr($_L['c_url'],$filts[$q]) !== false){
				$_L['c_url'] = str_replace($filts[$q],"",$_L['c_url']);
			}

			if(strstr($_L['c_bigo'],$filts[$q]) !== false){
				$_L['c_bigo'] = str_replace($filts[$q],"",$_L['c_bigo']);
			}

			if(strstr($_L['title'],$filts[$q]) !== false){
				$_L['title'] = str_replace($filts[$q],"",$_L['title']);
			}

			if(strstr($_L['keywords'],$filts[$q]) !== false){
				$_L['keywords'] = str_replace($filts[$q],"",$_L['keywords']);
			}

			if(strstr($_L['description'],$filts[$q]) !== false){
				$_L['description'] = str_replace($filts[$q],"",$_L['description']);
			}
		}
	}

	if ($_L['mode'] == 'insert'){
		$_L['no']	=	$db->get_data_one("SELECT MAX(no) FROM code");
		$_L['no']++;
		$query		=	"INSERT INTO code(
									no,
									c_name,
									c_code,
									c_parent,
									c_display,
									a_display,
									c_url,
									c_bigo,
									c_order,
									title,
									keywords,
									description,
									gubun,
									file1,
									real_filename1,
									file2,
									real_filename2,
									write_time					
									)
							VALUES(		
									'".$_L['no']."', 
									'".$_L['c_name']."', 
									'".$_L['c_code']."', 
									'".$_L['c_parent']."', 
									'".$_L['c_display']."', 
									'".$_L['a_display']."', 
									'".$_L['c_url']."', 
									'".$_L['c_bigo']."', 
									'".$_L['c_order']."', 
									'".$_L['title']."', 
									'".$_L['keywords']."', 
									'".$_L['description']."', 
									'".$_L['gubun']."',
									'".$_L['file1']."',
									'".$_L['real_filename1']."',
									'".$_L['file2']."',
									'".$_L['real_filename2']."',
									'".time()."'
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		if ($_L['file2'])	$add_query			.=	"file2		=	'".$_L['file2']."',";
		$query		=	"UPDATE code SET
										".$add_query."		
										c_name				=	'".$_L['c_name']."',
										c_display			=	'".$_L['c_display']."',
										a_display			=	'".$_L['a_display']."',
										c_url				=	'".$_L['c_url']."',
										c_bigo				=	'".$_L['c_bigo']."',
										title				=	'".$_L['title']."',
										keywords			=	'".$_L['keywords']."',
										description			=	'".$_L['description']."',
										real_filename1		=	'".$_L['real_filename1']."',
										real_filename2		=	'".$_L['real_filename2']."'
									WHERE
										no					=	'".$_L['no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM code
									WHERE
									no				=	'".$_L['no']."'

						";
		$query2		=	"DELETE FROM code
									WHERE
									c_code LIKE 		'".$_L['c_code']."%'

						";
		$db->query($query2);
	}

	$db->query($query);
	return $_L;
}



//=>	 카테고리목록 불러오기
function F_code_list($_L){
	global $db;
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['c_parent'] != null){
		$add_query		.=	" AND c_parent = '".$_L['c_parent']."'";
	}

	if ($_L['c2_parent'] != null){
		$add_query		.=	" AND c_parent LIKE '".$_L['c2_parent']."%'";
		$add_query		.=	" AND length(c_code) = 6 ";

	}

	if ($_L['top'] == true){
		$add_query		.=	" AND c_parent = ''";
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY no DESC ";
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													code 
													WHERE
													no IS NOT NULL
													$add_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						code 
					WHERE
						no IS NOT NULL
						$add_query
						$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";
	$c_list						=	$db->get_list($query);
	$c_list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$c_list['total']			=	$page_info['total'];
	$c_list['count']			=	count($c_list['no']);
	return $c_list;
}




function get_parent_code_name($code, $str, $db){
	global $cat_op;
	$z			=	strlen($code)/3;


	for ($i = 1; $i <= $z; $i++){
		$now_code		=	substr($code, 0, (3 * $i));
		if ($add_query){
			$add_query		.=	" OR  c_code = '$now_code'";
		}
		else {
			$add_query		=	" c_code = '$now_code' ";
		}
	}
	$query		=	"SELECT c_name FROM code WHERE $add_query ORDER BY c_code ASC ";

	$code_list	=	$db->get_list($query);
	for ($i = 0; $i < count($code_list['c_name']); $i++){
		$return		.=	' > '.$code_list['c_name'][$i];
	}
	$return			=	substr($return, 2, strlen($return));

	return $return;
}


function get_code_option($c_parent, $selected){
	$tmp		=	get_code($c_parent, $selected);
	$z			=	count($tmp['c_code']);
	for ($i = 0; $i < $z; $i++){
		$Array[$tmp['c_code'][$i]]		=	$tmp['c_name'][$i];
	}
	return	option_make($Array, $selected);
}

function get_code($c_parent, $selected){
	global $db;
	$tmp		=	$db->get_list("
								SELECT 
									c_code, 
									c_name 
								FROM 
									code 
								WHERE	
									c_parent		=	'$c_parent'
								ORDER BY c_code ASC
							");
	return	$tmp;
}


$F_code			=	1;
}
?>
