<?
//=>	정보 처리
function F_push_set($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									push_set 
									WHERE 
										no		=	'".$_L['no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);

	if($_L['mode'] == 'insert' || $_L['mode'] == 'update'){
		include_once $_SERVER['DOCUMENT_ROOT']."/_library/function_filter.php";

		$filt = $db->get_data("SELECT * FROM filter WHERE 1");
		$filts = array();
		if($filt['content'] != ''){
			if(strstr($filt['content'],",") != false){
				$filts = explode(",",$filt['content']);
			}else{
				$filts[] = $filt['content'];
			}
		}

		for($q=0;$q<count($filts);$q++){
			if(trim($filts[$q]) == ''){
				continue;
			}
			if(strstr($_L['o_content'],$filts[$q]) !== false){
				$_L['o_content'] = str_replace($filts[$q],"",$_L['o_content']);
			}

			if(strstr($_L['p_content'],$filts[$q]) !== false){
				$_L['p_content'] = str_replace($filts[$q],"",$_L['p_content']);
			}

			if(strstr($_L['r_content'],$filts[$q]) !== false){
				$_L['r_content'] = str_replace($filts[$q],"",$_L['r_content']);
			}

			if(strstr($_L['c_content'],$filts[$q]) !== false){
				$_L['c_content'] = str_replace($filts[$q],"",$_L['c_content']);
			}

			if(strstr($_L['g_content'],$filts[$q]) !== false){
				$_L['g_content'] = str_replace($filts[$q],"",$_L['g_content']);
			}

			if(strstr($_L['co_content'],$filts[$q]) !== false){
				$_L['co_content'] = str_replace($filts[$q],"",$_L['co_content']);
			}

			if(strstr($_L['b_content'],$filts[$q]) !== false){
				$_L['b_content'] = str_replace($filts[$q],"",$_L['b_content']);
			}

			if(strstr($_L['ch_content'],$filts[$q]) !== false){
				$_L['ch_content'] = str_replace($filts[$q],"",$_L['ch_content']);
			}

			if(strstr($_L['cm_content'],$filts[$q]) !== false){
				$_L['cm_content'] = str_replace($filts[$q],"",$_L['cm_content']);
			}

			if(strstr($_L['m_content'],$filts[$q]) !== false){
				$_L['m_content'] = str_replace($filts[$q],"",$_L['m_content']);
			}

			if(strstr($_L['s_content'],$filts[$q]) !== false){
				$_L['s_content'] = str_replace($filts[$q],"",$_L['s_content']);
			}

			if(strstr($_L['rq_content'],$filts[$q]) !== false){
				$_L['rq_content'] = str_replace($filts[$q],"",$_L['rq_content']);
			}
		}
	}

	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO push_set(										
										no,
										o_type,
										o_content,
										p_type,
										p_content,
										r_type,
										r_content,
										c_type,
										c_content,
										g_type,
										g_content,
										co_type,
										co_content,
										b_type,
										b_content,
										ch_type,
										ch_content,
										cm_type,
										cm_content,
										m_type,
										m_content,
										s_type,
										s_content,
										rq_type,
										rq_content,
										reg_date										
									)
							VALUES(									
										'".$_L['no']."',
										'".$_L['o_type']."',
										'".$_L['o_content']."',
										'".$_L['p_type']."',
										'".$_L['p_content']."',
										'".$_L['r_type']."',
										'".$_L['r_content']."',
										'".$_L['c_type']."',
										'".$_L['c_content']."',
										'".$_L['g_type']."',
										'".$_L['g_content']."',
										'".$_L['co_type']."',
										'".$_L['co_content']."',
										'".$_L['b_type']."',
										'".$_L['b_content']."',
										'".$_L['ch_type']."',
										'".$_L['ch_content']."',
										'".$_L['cm_type']."',
										'".$_L['cm_content']."',
										'".$_L['m_type']."',
										'".$_L['m_content']."',
										'".$_L['s_type']."',
										'".$_L['s_content']."',
										'".$_L['rq_type']."',
										'".$_L['rq_content']."',
										NOW()
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		$query		=	"UPDATE push_set SET
										".$add_query."										
										o_type			=	'".$_L['o_type']."',
										o_content		=	'".$_L['o_content']."',
										p_type			=	'".$_L['p_type']."',
										p_content		=	'".$_L['p_content']."',
										r_type			=	'".$_L['r_type']."',
										r_content		=	'".$_L['r_content']."',
										c_type			=	'".$_L['c_type']."',
										c_content		=	'".$_L['c_content']."',
										g_type			=	'".$_L['g_type']."',
										g_content		=	'".$_L['g_content']."',
										co_type			=	'".$_L['co_type']."',
										co_content		=	'".$_L['co_content']."',
										b_type			=	'".$_L['b_type']."',
										b_content		=	'".$_L['b_content']."',
										ch_type			=	'".$_L['ch_type']."',
										ch_content		=	'".$_L['ch_content']."',
										cm_type			=	'".$_L['cm_type']."',
										cm_content		=	'".$_L['cm_content']."',
										m_type			=	'".$_L['m_type']."',
										m_content		=	'".$_L['m_content']."',
										s_type			=	'".$_L['s_type']."',
										s_content		=	'".$_L['s_content']."',
										rq_type			=	'".$_L['rq_type']."',
										rq_content		=	'".$_L['rq_content']."'
									WHERE
									no			=	'".$_L['no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM push_set
									WHERE
									no				=	'".$_L['no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_push_set_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													push_set 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						push_set
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['no']);
	return $list;
}


?>
