<?
//=>	정보 처리
function F_sms_set($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									sms_set 
									WHERE 
										no		=	'".$_L['no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);

	if($_L['mode'] == 'insert' || $_L['mode'] == 'update'){
		include_once $_SERVER['DOCUMENT_ROOT']."/_library/function_filter.php";

		$filt = $db->get_data("SELECT * FROM filter WHERE 1");
		$filts = array();
		if($filt['content'] != ''){
			if(strstr($filt['content'],",") != false){
				$filts = explode(",",$filt['content']);
			}else{
				$filts[] = $filt['content'];
			}
		}

		for($q=0;$q<count($filts);$q++){
			if(trim($filts[$q]) == ''){
				continue;
			}
			if(strstr($_L['o_m_content'],$filts[$q]) !== false){
				$_L['o_m_content'] = str_replace($filts[$q],"",$_L['o_m_content']);
			}

			if(strstr($_L['o_a_content'],$filts[$q]) !== false){
				$_L['o_a_content'] = str_replace($filts[$q],"",$_L['o_a_content']);
			}

			if(strstr($_L['p_m_content'],$filts[$q]) !== false){
				$_L['p_m_content'] = str_replace($filts[$q],"",$_L['p_m_content']);
			}

			if(strstr($_L['p_a_content'],$filts[$q]) !== false){
				$_L['p_a_content'] = str_replace($filts[$q],"",$_L['p_a_content']);
			}

			if(strstr($_L['r_m_content'],$filts[$q]) !== false){
				$_L['r_m_content'] = str_replace($filts[$q],"",$_L['r_m_content']);
			}

			if(strstr($_L['r_a_content'],$filts[$q]) !== false){
				$_L['r_a_content'] = str_replace($filts[$q],"",$_L['r_a_content']);
			}

			if(strstr($_L['c_m_content'],$filts[$q]) !== false){
				$_L['c_m_content'] = str_replace($filts[$q],"",$_L['c_m_content']);
			}

			if(strstr($_L['c_a_content'],$filts[$q]) !== false){
				$_L['c_a_content'] = str_replace($filts[$q],"",$_L['c_a_content']);
			}

			if(strstr($_L['g_m_content'],$filts[$q]) !== false){
				$_L['g_m_content'] = str_replace($filts[$q],"",$_L['g_m_content']);
			}

			if(strstr($_L['g_a_content'],$filts[$q]) !== false){
				$_L['g_a_content'] = str_replace($filts[$q],"",$_L['g_a_content']);
			}
		}
	}

	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO sms_set(										
										no,
										o_m_type,
										o_m_content,
										o_a_type,
										o_a_content,
										p_m_type,
										p_m_content,
										p_a_type,
										p_a_content,
										r_m_type,
										r_m_content,
										r_a_type,
										r_a_content,
										c_m_type,
										c_m_content,
										c_a_type,
										c_a_content,
										g_m_type,
										g_m_content,
										g_a_type,
										g_a_content,
										reg_date										
									)
							VALUES(									
										'".$_L['no']."',
										'".$_L['o_m_type']."',
										'".$_L['o_m_content']."',
										'".$_L['o_a_type']."',
										'".$_L['o_a_content']."',
										'".$_L['p_m_type']."',
										'".$_L['p_m_content']."',
										'".$_L['p_a_type']."',
										'".$_L['p_a_content']."',
										'".$_L['r_m_type']."',
										'".$_L['r_m_content']."',
										'".$_L['r_a_type']."',
										'".$_L['r_a_content']."',
										'".$_L['c_m_type']."',
										'".$_L['c_m_content']."',
										'".$_L['c_a_type']."',
										'".$_L['c_a_content']."',
										'".$_L['g_m_type']."',
										'".$_L['g_m_content']."',
										'".$_L['g_a_type']."',
										'".$_L['g_a_content']."',
										NOW()
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		$query		=	"UPDATE sms_set SET
										".$add_query."										
										o_m_type		=	'".$_L['o_m_type']."',
										o_m_content		=	'".$_L['o_m_content']."',
										o_a_type		=	'".$_L['o_a_type']."',
										o_a_content		=	'".$_L['o_a_content']."',
										p_m_type		=	'".$_L['p_m_type']."',
										p_m_content		=	'".$_L['p_m_content']."',
										p_a_type		=	'".$_L['p_a_type']."',
										p_a_content		=	'".$_L['p_a_content']."',
										r_m_type		=	'".$_L['r_m_type']."',
										r_m_content		=	'".$_L['r_m_content']."',
										r_a_type		=	'".$_L['r_a_type']."',
										r_a_content		=	'".$_L['r_a_content']."',
										c_m_type		=	'".$_L['c_m_type']."',
										c_m_content		=	'".$_L['c_m_content']."',
										c_a_type		=	'".$_L['c_a_type']."',
										c_a_content		=	'".$_L['c_a_content']."',
										g_m_type		=	'".$_L['g_m_type']."',
										g_m_content		=	'".$_L['g_m_content']."',
										g_a_type		=	'".$_L['g_a_type']."',
										g_a_content		=	'".$_L['g_a_content']."'
									WHERE
									no			=	'".$_L['no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM sms_set
									WHERE
									no				=	'".$_L['no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_sms_set_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													sms_set 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						sms_set
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['no']);
	return $list;
}


?>
