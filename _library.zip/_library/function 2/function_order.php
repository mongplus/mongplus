<?
//=>	정보 처리
function F_order($_L){
	global $db;
	$add_query		=	"";
	$_L['price']			=	preg_replace("/[^0-9\-]/","", $_L['price']);
	if ($_L['mode'] == 'read'){
		$info		=	$db->get_data("
									SELECT 
										*
									FROM 
									`order` 
									WHERE 
										order_no		=	'".$_L['order_no']."' 
									");
	$info				=	F_strip_slashes($info);
	return	$info;
	}

	$_L					=	F_add_slashes($_L);

	if($_L['mode'] == 'insert' || $_L['mode'] == 'update'){
		include_once $_SERVER['DOCUMENT_ROOT']."/_library/function_filter.php";

		$filt = $db->get_data("SELECT * FROM filter WHERE 1");
		$filts = array();
		if($filt['content'] != ''){
			if(strstr($filt['content'],",") != false){
				$filts = explode(",",$filt['content']);
			}else{
				$filts[] = $filt['content'];
			}
		}

		for($q=0;$q<count($filts);$q++){
			if(trim($filts[$q]) == ''){
				continue;
			}

			if(strstr($_L['pay_name'],$filts[$q]) !== false){
				$_L['pay_name'] = str_replace($filts[$q],"",$_L['pay_name']);
			}

			if(strstr($_L['or_name'],$filts[$q]) !== false){
				$_L['or_name'] = str_replace($filts[$q],"",$_L['or_name']);
			}

			if(strstr($_L['or_nickname'],$filts[$q]) !== false){
				$_L['or_nickname'] = str_replace($filts[$q],"",$_L['or_nickname']);
			}

			if(strstr($_L['or_addr1'],$filts[$q]) !== false){
				$_L['or_addr1'] = str_replace($filts[$q],"",$_L['or_addr1']);
			}

			if(strstr($_L['or_addr2'],$filts[$q]) !== false){
				$_L['or_addr2'] = str_replace($filts[$q],"",$_L['or_addr2']);
			}

			if(strstr($_L['re_name'],$filts[$q]) !== false){
				$_L['re_name'] = str_replace($filts[$q],"",$_L['re_name']);
			}

			if(strstr($_L['re_addr1'],$filts[$q]) !== false){
				$_L['re_addr1'] = str_replace($filts[$q],"",$_L['re_addr1']);
			}

			if(strstr($_L['re_addr2'],$filts[$q]) !== false){
				$_L['re_addr2'] = str_replace($filts[$q],"",$_L['re_addr2']);
			}

			if(strstr($_L['order_memo'],$filts[$q]) !== false){
				$_L['order_memo'] = str_replace($filts[$q],"",$_L['order_memo']);
			}
		}
	}

	if ($_L['mode'] == 'insert'){
		$query		=	"INSERT INTO `order`(										
										order_no,
										order_code,
										member_no,
										product_no,
										product_name,
										product_code,
										total_price,
										true_price,
										sale_price,
										ship_price,
										sale_member_price,
										sale_coupon_price,
										sale_admin_price,
										plus_price,
										plus_admin_sale,
										return_price,
										pay_type,
										pay_easy,
										pay_card,
										pay_name,
										status,
										pay_addr,
										o_add_status,
										pay_date,
										or_name,
										or_id,
										or_tel,
										or_mobile,
										or_email,
										or_nickname,
										or_zipcode,
										or_addr1,
										or_addr2,
										re_name,
										re_tel,
										re_mobile,
										re_email,
										re_zipcode,
										re_addr1,
										re_addr2,
										order_memo,
										invoice_no,
										ship_company,
										cancel_date,
										refund_date,
										return_date,
										cancel_ok_date,
										refund_ok_date,
										return_ok_date,
										ok_date,
										review,
										is_sms,
										reg_date										
									)
							VALUES(									
										'".$_L['order_no']."',
										'".$_L['order_code']."',
										'".$_L['member_no']."',
										'".$_L['product_no']."',
										'".$_L['product_name']."',
										'".$_L['product_code']."',
										'".$_L['total_price']."',
										'".$_L['true_price']."',
										'".$_L['sale_price']."',
										'".$_L['ship_price']."',
										'".$_L['sale_member_price']."',
										'".$_L['sale_coupon_price']."',
										'".$_L['sale_admin_price']."',
										'".$_L['plus_price']."',
										'".$_L['plus_admin_sale']."',
										'".$_L['return_price']."',
										'".$_L['pay_type']."',
										'".$_L['pay_easy']."',
										'".$_L['pay_card']."',
										'".$_L['pay_name']."',
										'".$_L['status']."',
										'".$_L['pay_addr']."',
										'".$_L['o_add_status']."',
										'".$_L['pay_date']."',
										'".$_L['or_name']."',
										'".$_L['or_id']."',
										'".$_L['or_tel']."',
										'".$_L['or_mobile']."',
										'".$_L['or_email']."',
										'".$_L['or_nickname']."',
										'".$_L['or_zipcode']."',
										'".$_L['or_addr1']."',
										'".$_L['or_addr2']."',
										'".$_L['re_name']."',
										'".$_L['re_tel']."',
										'".$_L['re_mobile']."',
										'".$_L['re_email']."',
										'".$_L['re_zipcode']."',
										'".$_L['re_addr1']."',
										'".$_L['re_addr2']."',
										'".$_L['order_memo']."',
										'".$_L['invoice_no']."',
										'".$_L['ship_company']."',
										'".$_L['cancel_date']."',
										'".$_L['refund_date']."',
										'".$_L['return_date']."',
										'".$_L['cancel_ok_date']."',
										'".$_L['refund_ok_date']."',
										'".$_L['return_ok_date']."',
										'".$_L['ok_date']."',
										'".$_L['review']."',
										'".$_L['is_sms']."',
										NOW()
									)
						";
	}
	if ($_L['mode'] == 'update'){
		if ($_L['file1'])	$add_query			.=	"file1		=	'".$_L['file1']."',";
		$query		=	"UPDATE `order` SET
										".$add_query."										
										order_code		=	'".$_L['order_code']."',
										member_no		=	'".$_L['member_no']."',
										product_no		=	'".$_L['product_no']."',
										product_name	=	'".$_L['product_name']."',
										product_code	=	'".$_L['product_code']."',
										total_price		=	'".$_L['total_price']."',
										true_price		=	'".$_L['true_price']."',
										sale_price		=	'".$_L['sale_price']."',
										ship_price		=	'".$_L['ship_price']."',
										sale_member_price=	'".$_L['sale_member_price']."',
										sale_coupon_price=	'".$_L['sale_coupon_price']."',
										sale_admin_price=	'".$_L['sale_admin_price']."',
										plus_price		=	'".$_L['plus_price']."',
										plus_admin_sale	=	'".$_L['plus_admin_sale']."',
										return_price	=	'".$_L['return_price']."',
										pay_type		=	'".$_L['pay_type']."',
										pay_easy		=	'".$_L['pay_easy']."',
										pay_card		=	'".$_L['pay_card']."',
										pay_name		=	'".$_L['pay_name']."',
										status			=	'".$_L['status']."',
										pay_addr		=	'".$_L['pay_addr']."',
										pay_addr		=	'".$_L['pay_addr']."',
										o_add_status	=	'".$_L['o_add_status']."',
										or_name			=	'".$_L['or_name']."',
										or_id			=	'".$_L['or_id']."',
										or_tel			=	'".$_L['or_tel']."',
										or_mobile		=	'".$_L['or_mobile']."',
										or_email		=	'".$_L['or_email']."',
										or_nickname		=	'".$_L['or_nickname']."',
										or_zipcode		=	'".$_L['or_zipcode']."',
										or_addr1		=	'".$_L['or_addr1']."',
										or_addr2		=	'".$_L['or_addr2']."',
										re_name			=	'".$_L['re_name']."',
										re_tel			=	'".$_L['re_tel']."',
										re_mobile		=	'".$_L['re_mobile']."',
										re_email		=	'".$_L['re_email']."',
										re_zipcode		=	'".$_L['re_zipcode']."',
										re_addr1		=	'".$_L['re_addr1']."',
										re_addr2		=	'".$_L['re_addr2']."',
										order_memo		=	'".$_L['order_memo']."',
										invoice_no		=	'".$_L['invoice_no']."',
										ship_company	=	'".$_L['ship_company']."',
										cancel_date		=	'".$_L['cancel_date']."',
										refund_date		=	'".$_L['refund_date']."',
										return_date		=	'".$_L['return_date']."',
										cancel_ok_date	=	'".$_L['cancel_ok_date']."',
										refund_ok_date	=	'".$_L['refund_ok_date']."',
										return_ok_date	=	'".$_L['return_ok_date']."'
									WHERE
									order_no			=	'".$_L['order_no']."'
						";
	}

	if ($_L['mode'] == 'delete'){
		$query		=	"DELETE FROM `order`
									WHERE
									order_no				=	'".$_L['order_no']."'
						";
	}
	$db->query($query);
}



//=>	 목록 불러오기
function F_order_list($_L){
	global $db;
	$add_query		=	"";
	$wheres				 =  $_L['wheres'];
	$_L					=	F_add_slashes($_L);
	if ($_L['find_object'] != null && $_L['find_text'] != null){
		$add_query		.=	" AND ".$_L['find_object']." LIKE  '%".$_L['find_text']."%' ";
	}
	if ($_L['add_query']){
		$add_query		.=	stripslashes($_L['add_query']);
	}
	if ($_L['s_area']){
		$add_query		.=	" AND area = '".$_L['s_area']."' ";
	}
	if ($wheres){
		$add_query		.=	$wheres;
	}

	//=>	정렬기준
	if ($_L['order'] != null){
		$order_query		=	" ORDER BY ".$_L['order']." ";
	}
	else{
		$order_query		=	" ORDER BY order_no DESC ";
	}
	if (sub_eregi("DESC", $order_query)){
		$order_query_2		=	str_replace(" DESC", " ASC", $order_query);
	}
	else{
		$order_query_2		=	str_replace(" ASC", " DESC", $order_query);
	}

	//=>	페이지 네비게이션 표시
	if (!$_L['page']){
		$_L['page'] = 1;
	}
	if ($add_query){
		$querylen			=	strlen($add_query);
		$where_query		=	" WHERE ".substr($add_query, 4, $querylen-4);
	}
	$page_info['cur']		=	$_L['page'];
	$page_info['row']		=	$_L['row'];
	$count_now				=	$page_info['row']*($page_info['cur'] - 1); 
	$top_rows				=	$_L['page'] * $_L['row'];
	$page_info['total']		=	$db->get_data_one("SELECT 
													count(*)
													FROM
													`order` 
													$where_query
													");

	//=>	위의 조건에 따라 목록 가져오기
	$query		=	"
					SELECT
						*
					FROM
						`order`
					$where_query
					$order_query
						LIMIT ".$count_now.",".$page_info['row']."
						";

	$list						=	$db->get_list($query);

	$list['page_string']		=	print_page_num($page_info);		//페이지 번호 출력하는 
	$list['total']				=	$page_info['total'];
	$list['row']				=	$_L['row'];
	$list['count']				=	count($list['order_no']);
	return $list;
}


?>
